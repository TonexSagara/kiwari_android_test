package com.example.chatapp;

public class StartActivity extends AppCompatActivity {

    TextView fireData; //Untuk menampilkan data dari firebase
    Firebase ref; //Initialiasi Firebase untuk project

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Firebase.setAndroidContext(this);

        fireData = (TextView) findViewById(R.id.firebase_textview);
        ref = new Firebase("https://wirasetiawan29.firebaseio.com/chat");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String superData = (String) dataSnapshot.getValue();
                fireData.setText(superData);
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
        });
    }
}

